#!/bin/bash

cd /data/hbutler/socfpga-buildroot/socfpga-4.1.22-ltsi/
make socfpga_defconfig
make socfpga_cyclone5_howard.dtb
cp /data/hbutler/socfpga-buildroot/socfpga-4.1.22-ltsi/arch/arm/boot/dts/socfpga_cyclone5_howard.dtb /var/lib/tftpboot/DE0_NANO_SOC/soc_system.dtb
cd /home/hbutler/sd_card_contents/DE0_NANO_SOC/my_dts
