#include "gpio.h"
#include "mem_map.h"
#include "portmux.h"
#include "ports.h"

#define CONFIG_BF52x 1	/* Linux glue */
