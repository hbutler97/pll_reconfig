#include "gpio.h"
#include "portmux.h"
#include "ports.h"

#define BF538_FAMILY 1	/* Linux glue */
