#include "gpio.h"
#include "portmux.h"
#include "ports.h"

#define CONFIG_BF51x 1	/* Linux glue */
